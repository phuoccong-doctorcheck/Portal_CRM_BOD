import React from 'react';

interface NotificationSettingProps {
}

const NotificationSetting: React.FC<NotificationSettingProps> = ({ }) => (
  <div></div>
);

NotificationSetting.defaultProps = {
};

export default NotificationSetting;
