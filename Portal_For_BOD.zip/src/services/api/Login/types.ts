///
export type Typecase = {

};
